package com.mycompany.volley;
 
import android.app.Activity;
import android.os.Bundle;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.Response;
import javax.xml.transform.ErrorListener;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import android.widget.TextView;

public class MainActivity extends Activity { 
     private RequestQueue requestqueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		/*
		@time:2022.7.7
		@writer:Lsir
		@qq:2913141342
		@name:volley网络框架的使用
		*/
		String url = "https://m.baidu.com";
        requestqueue = Volley.newRequestQueue(this);
		StringRequest string = new StringRequest(Request.Method.GET, url, new Response.Listener<String>(){

				@Override
				public void onResponse(String p1) {
					TextView tv = findViewById(R.id.activitymainTextView1);
					tv.setText(p1);
				}
			}, new Response.ErrorListener(){

				@Override
				public void onErrorResponse(VolleyError p1) {
					TextView tv = findViewById(R.id.activitymainTextView1);
					tv.setText(p1.toString());
				}
			});
			requestqueue.add(string);
}
		
	public RequestQueue getRequestQueue()
	{
		return requestqueue;
		}
	
} 
